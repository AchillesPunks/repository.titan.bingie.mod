# Skin Titan BINGIE MOD

Titan BINGIE MOD for Kodi Omega.

This development branch uses Skin Shortcuts 3.0.5 or newer, including its native menu and widget editor. Skin Shortcuts v3 stores custom menus separately from v2 and does not automatically import v2 customisations. Back up your Kodi userdata before trying this branch; existing v2 menus remain available when restoring the original skin and helper.

## Extended Movies and TV Shows hubs

The existing eight hub rows remain the default. To use up to 24 rows, enable **Extended Movies and TV Shows hubs (24 rows)** under Skin settings > Configure shortcuts. The skin reloads when this option changes.

Unlock hub widgets, open Movies or TV Shows, and use each row's existing widget picker to choose its source and label. For example, assign Continue Watching, Trending, New Releases and individual genre lists from the add-ons you already use. No provider or account is required by the skin change itself, and no personal feed choices are included.

Extended hubs load the first three rows, then prefetch two rows ahead as you move down. Configured rows that are empty or still loading remain reachable, including after gaps between configured rows. Other hubs and the Home layout keep their existing behaviour.

Turn the option off to return to eight rows. Additional row settings are retained for the next time you enable it.

## Optional TMDb New & Popular shelves

Under Skin settings > Configure shortcuts, choose Apply TMDb New & Popular shelves to configure New movies, New TV shows, Popular movies and Popular TV shows. The previous first four rows are backed up. Restore previous New & Popular shelves restores those rows after confirmation; other hubs and later rows remain unchanged.

This build also uses the retained standard switch images in the widget editor, including Force Refresh and Highlight. It retains the maintainer's complete 2.2.3.1 files and views.

#IMPORTANT NOTE FOR USERS# 
Install the skin through the official titan bingie mod repository for updates and the supported addons required!
The content here is for developing purposes!
https://github.com/AchillesPunks/repository.titan.bingie.mod

Join the official thread for updates: https://forum.kodi.tv/showthread.php?tid=355993

Special Thanks to @marcelveldt and @cartman.dos for all of his work on the original code for Titan and Titan BINGIE skin & addons 
and everyone else who have helped or contributed in any way!
